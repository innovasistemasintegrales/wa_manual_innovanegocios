import mysql from 'mysql'
try {
    const conecction = mysql.createConnection({
        host: '',
        user: '',
        password: '',
    })
} catch (error) {
    
}